
---
tags:
- phosphobot
- so100
- phospho-dk
task_categories:
- robotics                                                   
---

# plant_square_pour_2

**This dataset was generated using a [phospho starter pack](https://robots.phospho.ai).**

This dataset contains a series of episodes recorded with a robot and multiple cameras. It can be directly used to train a policy using imitation learning. It's compatible with LeRobot and RLDS.
